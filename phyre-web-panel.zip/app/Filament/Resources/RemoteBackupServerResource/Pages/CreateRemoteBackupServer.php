<?php

namespace App\Filament\Resources\RemoteBackupServerResource\Pages;

use App\Filament\Resources\RemoteBackupServerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRemoteBackupServer extends CreateRecord
{
    protected static string $resource = RemoteBackupServerResource::class;
}
