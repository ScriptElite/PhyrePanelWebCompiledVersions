<?php

namespace App\Filament\Resources\PhyreServerResource\Pages;

use App\Filament\Resources\PhyreServerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePhyreServer extends CreateRecord
{
    protected static string $resource = PhyreServerResource::class;
}
