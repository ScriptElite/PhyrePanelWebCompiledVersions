<?php

return [
    'name' => 'Terminal',
];
