<div>
    <div class="bg-black/5 dark:bg-white/5 dark:text-green-500 p-4 rounded">
    {!! $this->containerLog !!}
    </div>
</div>
