<x-filament-panels::page>
    <div>
        {{ $this->table }}
    </div>
</x-filament-panels::page>
