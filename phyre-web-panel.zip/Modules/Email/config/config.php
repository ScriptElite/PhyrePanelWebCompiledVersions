<?php

return [
    'name' => 'Email',
];
