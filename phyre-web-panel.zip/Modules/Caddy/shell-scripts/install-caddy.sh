#!/bin/bash

sudo apt-get install net-tools -y

sudo apt-get install curl -y



echo "Done!"
