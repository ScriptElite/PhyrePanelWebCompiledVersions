<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Email\\App\\Providers\\EmailServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Email\\App\\Providers\\EmailServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);