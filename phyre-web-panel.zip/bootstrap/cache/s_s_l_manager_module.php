<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SSLManager\\App\\Providers\\SSLManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SSLManager\\App\\Providers\\SSLManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);