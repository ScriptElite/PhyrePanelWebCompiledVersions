<div>

    <a href="/">
        <img alt="Phyre - Hosting Panel" src="{{asset('images/phyre-logo.svg')}}"
             style="height: 2rem;" class="fi-logo flex">
    </a>

</div>
